--Query B

CREATE TABLE Game(
gam_Name CHAR(50) NOT NULL UNIQUE,
gam_Date DATE NOT NULL,
gam_MinAge INT NOT NULL,
gam_Price DECIMAL(7,2) NOT NULL,
PRIMARY KEY(gam_Name)
);

CREATE TABLE Customer(
cus_ID CHAR(10) NOT NULL UNIQUE,
cus_Initials CHAR(5) NOT NULL,
cus_Surname CHAR(50) NOT NULL,
cus_Country CHAR(50) NOT NULL,
cus_DOB DATE NOT NULL,
PRIMARY KEY(cus_ID)
);

CREATE TABLE Subscribe(
gam_Name CHAR(50) NOT NULL,
cus_ID CHAR(10) NOT NULL,
sub_Rate INT NOT NULL CHECK(sub_Rate < 6 AND sub_Rate > 0),
FOREIGN KEY(gam_Name) REFERENCES Game,
FOREIGN KEY(cus_ID) REFERENCES Customer,
PRIMARY KEY (gam_Name, cus_ID)
);

CREATE TABLE Hint(
hin_Num INT NOT NULL UNIQUE,
hin_Desc CHAR(150) NOT NULL,
hin_Publish DATE NOT NULL,
hin_Dev CHAR(50) NOT NULL,
gam_Name CHAR(50) NOT NULL,
FOREIGN KEY(gam_Name) REFERENCES Game,
PRIMARY KEY(hin_Num),

);

CREATE TABLE Comment(
cus_ID CHAR(10) NOT NULL,
hin_Num INT NOT NULL,
com_Num INT NOT NULL, --The number of times a customer has commented on a specific hint
com_Desc CHAR(150) NOT NULL,
com_Date DATE NOT NULL,
FOREIGN KEY(cus_ID) REFERENCES Customer,
FOREIGN KEY(hin_Num) REFERENCES Hint,
PRIMARY KEY (cus_ID, hin_Num, com_Num)
);


--Query C

INSERT INTO Game VALUES
('FortNights','2000/01/03',13,350.20),
('MinesCraft','2010/02/10',16,900.20);

INSERT INTO Customer VALUES
('0123456789','AB','Sischy','South Africa', '2002/02/10'),
('1123456789','CD','South','USA', '2010/05/09');

INSERT INTO Subscribe VALUES 
('FortNights','0123456789',3),
('FortNights','1123456789',1);

INSERT INTO Hint VALUES
(1,'Inside Triangle','2001/01/03','Jack Right', 'FortNights'),
(2,'Near Tree','2002/01/03','Jack Right', 'FortNights');

INSERT INTO Comment VALUES
('0123456789',1,1,'Was very helpful','2003/01/03'),
('0123456789',1,2,'Was NOT very helpful','2003/02/05');



--Query D

SELECT *
FROM Game
ORDER BY gam_Price DESC;


--Query E

Select Game.gam_Name, AVG(Subscribe.sub_Rate) AS [AVG_Rating]
FROM Game LEFT JOIN Subscribe --null means no rating 
ON Game.gam_Name = Subscribe.gam_Name
GROUP BY Game.gam_Name;


--Query F

Select Game.gam_Name, Hint.Hin_Desc, Hint.Hin_Num
FROM Game INNER JOIN Hint
ON Game.gam_Name = Hint.gam_Name;



--Query G

Select Customer.cus_ID, Subscribe.gam_Name, Subscribe.sub_Rate
FROM Customer, Subscribe
WHERE Customer.cus_ID = Subscribe.cus_ID;


--Query H
SELECT Game.gam_Name, Game.gam_Price, AVG(Subscribe.sub_Rate) AS [AVG_Rating]
FROM Game INNER JOIN Subscribe
ON Game.gam_Name = Subscribe.gam_Name
GROUP BY Game.gam_Name,Game.gam_Price
HAVING AVG(Subscribe.sub_Rate) =
(
SELECT min(AVG_Rating)
FROM
(
Select Game.gam_Name,AVG(Subscribe.sub_Rate) AS [AVG_Rating]
FROM Game INNER JOIN Subscribe
ON Game.gam_Name = Subscribe.gam_Name
GROUP BY Game.gam_Name
)sub_Rate
)



