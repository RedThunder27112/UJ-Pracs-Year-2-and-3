﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Assignment2_CS
{
    class Mammalia : Chordata
    {
        public Mammalia()
        {
            bloodtype = Bloodtype.Warm;
        }
    }
}
