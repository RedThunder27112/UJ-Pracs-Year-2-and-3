﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Assignment1_CS
{
    abstract class Shape
    {
        public abstract double Area();

    }
}
