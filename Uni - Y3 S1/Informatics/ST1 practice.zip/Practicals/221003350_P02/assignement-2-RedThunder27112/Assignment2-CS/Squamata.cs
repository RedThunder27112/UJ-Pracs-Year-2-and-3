﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Assignment2_CS
{
    class Squamata : Reptilia
    {
        public Squamata ()
        {

        }
    }
}
