There is a runnable .jar in docs. (This does require javaFX arguments to be added in CMD when running)

For ease of use, there is a batch file which containes these arguments that can be run. (In docs as well)