

import java.util.ArrayList;
import java.util.Iterator;
import java.util.StringTokenizer;

import com.jwetherell.algorithms.data_structures.Graph;
import com.jwetherell.algorithms.data_structures.Graph.Vertex;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextArea;
import javafx.scene.input.MouseDragEvent;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Line;
import javafx.scene.shape.Polygon;
import javafx.scene.shape.Shape;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

public class GraphPane extends StackPane
{
	static Pane pane;
	static int total;
	static int totalTime;
	static TextArea txtTotal;
	static TextArea txtBudget;
	static GridPane gridPane;
	static GraphPane graphPane;
	static Tree<Vertex<Choice>> tree;
	static Position<Vertex<Choice>> root;
	static ScrollPane scrollPane;
	
	static ArrayList<Position<Vertex<Choice>>> vertexPath = new ArrayList<Position<Vertex<Choice>>>();
	static ArrayList<Button> choicePath = new ArrayList<Button>();
	static ArrayList<Button> listButtons = new ArrayList<Button>();
	static int choiceNumber = -1;
	static boolean longPath = false;
	
	public GraphPane()
	{
		
		graphPane = this;
		gridPane = new GridPane();
		//setting vbox/controls
		VBox vbox = new VBox();
		vbox.setPrefSize(1200, 800);
		//setting pane/graph
		pane = new Pane();
		pane.setPrefSize(USE_COMPUTED_SIZE, USE_COMPUTED_SIZE);
		
		//scrollpane
		scrollPane = new ScrollPane();
		scrollPane.setContent(pane);
		scrollPane.setPrefSize(600, 600);
		//adding both to main borderpane for layout



		
		//adding controls to vbox
		Label lblTotal = new Label("Current Total:");
		txtTotal = new TextArea();
		txtTotal.setPrefSize(getPrefWidth(), 30);
		
		Label lblBudget = new Label("Please Enter Your Total Budget Here:");
		txtBudget = new TextArea();
		txtBudget.setPrefSize(getPrefWidth(), 20);
		
		//add buttons
		
		Button btnGoBack = new Button("Go Back One Choice");
		btnGoBack.setPrefSize(200, 30);
		
		Button btnReset = new Button("Reset Choices");
		btnReset.setPrefSize(200, 30);
		
		Button btnDisplayChoices = new Button("Display Current Choices Info");
		btnDisplayChoices.setPrefSize(200, 30);
		
		Button btnShortPath = new Button("Shortest Path");
		btnShortPath.setPrefSize(200, 30);
		
		Button btnLongPath= new Button("Longest Path (Money is no issue)");
		btnLongPath.setPrefSize(200, 30);

		Button btnExpensiveAffordable = new Button("Most expensive path you can afford");
		btnExpensiveAffordable.setPrefSize(200, 30);

		
		gridPane.add(lblTotal, 0, 0);
		gridPane.add(txtTotal, 0, 1);
		gridPane.add(lblBudget, 0, 2);
		gridPane.add(txtBudget, 0, 3);
		gridPane.add(btnGoBack, 0, 4);
		gridPane.add(btnReset, 1, 0);
		gridPane.add(btnExpensiveAffordable, 1, 1);
		gridPane.add(btnShortPath, 1, 2);
		gridPane.add(btnLongPath, 1, 3);
		gridPane.add(btnDisplayChoices, 1, 4);
		
		vbox.getChildren().add(gridPane);
		vbox.getChildren().add(scrollPane);
		
		this.getChildren().add(vbox);
		
		//generate tree and fill it
		ModifyTree modifyTree = new ModifyTree();
		
		//tree = modifyTree.getTree();
		tree = modifyTree.graphToTree();
		root = modifyTree.getRoot();
		
		try 
		{

			
			displayNodes(tree, root);
			displayEdge(tree, root);
			//System.out.println(tree.preOrderElementTraversal(tree, root));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		//set buttons actipns
		
		btnGoBack.setOnAction(new EventHandler <ActionEvent>()
		{
			@Override
			public void handle(ActionEvent event) 
			{
				goBack();
			}		
		});
		
		btnReset.setOnAction(new EventHandler <ActionEvent>()
		{
			@Override
			public void handle(ActionEvent event) 
			{
				resetNodes();
			}		
		});
		
		btnDisplayChoices.setOnAction(new EventHandler <ActionEvent>()
		{
			@Override
			public void handle(ActionEvent event) 
			{

				printChoices();
				graphPane.setVisible(false);
				//opens main menu
				ResultsPane root = new ResultsPane(vertexPath, graphPane);
				Stage secondStage = new Stage();
				
				//secondStage.initStyle(StageStyle.UNDECORATED);
		        secondStage.setScene(new Scene(root));
		        secondStage.setTitle("Results");
		        secondStage.show();
			}		
		});
		
		btnShortPath.setOnAction(new EventHandler <ActionEvent>()
		{
			@Override
			public void handle(ActionEvent event) 
			{
				longPath = true;
				
				try {
					if(vertexPath.isEmpty())
					{
						addToPath(root, listButtons.get(0));
					}
					shortestPath(vertexPath.get(choiceNumber));
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				longPath = false;

			}		
		});
		
		btnLongPath.setOnAction(new EventHandler <ActionEvent>()
		{
			@Override
			public void handle(ActionEvent event) 
			{
				longPath = true;
				

				try {
					if(vertexPath.isEmpty())
					{
						addToPath(root, listButtons.get(0));
					}
					longestPath(vertexPath.get(choiceNumber));
				} catch (Exception e) 
				{
					e.printStackTrace();
				}
				longPath = false;

			}		
		});

		
		btnExpensiveAffordable.setOnAction(new EventHandler <ActionEvent>()
		{
			@Override
			public void handle(ActionEvent event) 
			{

				longPath = true;
				try {

					resetNodes();
					mostExpensiveAffordablePath(tree, root, 0, "");

					StringTokenizer st = new StringTokenizer(tempMaxString);
					while(st.hasMoreTokens())
					{
						int id = Integer.parseInt(st.nextToken());
						System.out.println(id);
						Position<Vertex<Choice>>  vertex = getVertexByID(tree,root,id,root);
						addToPath(vertex,searchButtonbyID(vertex.element().getValue().getID()));
					}
					
					if(tempMaxString.length() < 1)
					{
						//resetNodes();
						errorMessage("ERROR: There is no possible path that is affordable with the current budget");
					}

					System.out.println("Most: "+ tempMaxTotal);
					System.out.println("Most S : "+ tempMaxString);
					
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				longPath = false;
				 

			}		
		});

		////
		
	}
	
	public static void goBack()
	{
		
		//if choice exists
		if(choiceNumber > -1)
		{
			//go back one on button
			Button button = choicePath.get(choiceNumber);
			button.setTextFill(null);
			button.setStyle("-fx-background-color: BLACK");
			System.out.println(button.getText());
			//go back on 
			Position<Vertex<Choice>> vertex = vertexPath.get(choiceNumber);
			vertex.element().getValue().setDisplayed(false);
			vertex.element().getValue().setVisited(false);
			
			//now get rid of button and vertex from list
			vertexPath.remove(choiceNumber);
			choicePath.remove(choiceNumber);
			
			total -= vertex.element().getWeight();
			totalTime -= vertex.element().getValue().getTotalTime();
			txtTotal.setText("Money: R"+total+"\nTime: "+totalTime);
			
			choiceNumber--;
			
			
		}else
		{
			errorMessage("ERROR: There is no node selected to undo.");
			return;
		}

	}
	
	public static void addToPath(Position<Vertex<Choice>> elem,Button button)
	{
		if(longPath)
		{	
		}else
		if(!canAfford(elem.element().getWeight()))
		{
			errorMessage("ERROR: You cannot afford this choice.");
			return;
		}
		
		
		elem.element().getValue().setVisited(true);
        button.setTextFill(Color.BLUE);
        button.setStyle("-fx-background-color: BLUE");
        
		vertexPath.add(elem);
		choicePath.add(button);
		choiceNumber++;
		
		total += elem.element().getWeight();
		totalTime += elem.element().getValue().getTotalTime();
		txtTotal.setText("Money: R"+total+"\nTime: "+totalTime+"hrs");
		
	}
	
	final static int nodeSize = 50;
	final static int edgeSize = 50;
	public static void addNode(int x, int y, Position<Vertex<Choice>> elem)
	{
		
		Button button = new Button(""+elem.element().getValue().getID());
		button.setShape(new Circle(10));
		button.setPrefSize(nodeSize,nodeSize);
		button.setLayoutX(x);
		button.setLayoutY(y);
		button.setTextFill(null);
		button.setStyle("-fx-background-color: BLACK");
		
		Label lblName = new Label(elem.element().getValue().getName());
		lblName.setLayoutX(x);
		lblName.setLayoutY(y-15);

		
		listButtons.add(button);
		
		pane.getChildren().add(lblName);
		pane.getChildren().add(button);
		

		button.setOnAction(new EventHandler <ActionEvent>()
		{
			
			@Override
			public void handle(ActionEvent event) 
			{

				txtTotal.setText("Money: R"+total+"\nTime: "+totalTime+"hrs");
				
				//this is to search if parent has been visisted
				searchResult = false;
				//this is to search if a fellow child has been visited
				searchChildResult = true;
				try 
				{
					searchParentVisited(tree,  root, Integer.parseInt(button.getText()));
					searchFellowChildVisited(tree,  root, Integer.parseInt(button.getText()));
	
				} catch (Exception e) 
				{
					e.printStackTrace();
				}
				
				
				//if parent not visited yet
				if(!searchResult)
				{
					//go to error pane
					errorMessage("ERROR: Parent of Choice not selected yet.");
			        return;
					
				}else
				if(!searchChildResult)//now check if a fellow child has already been chosen
				{
								
					//go to error pane
					errorMessage("ERROR: You cannot choose more than one choice at the same depth");
			        return;
					
					
				}else
				if(button.getTextFill() == null)//if button viable
				{
					graphPane.setVisible(false);
					//opens main menu
					InfoPane root = new InfoPane(elem, button, graphPane);
					Stage secondStage = new Stage();
					
					//secondStage.initStyle(StageStyle.UNDECORATED);
			        secondStage.setScene(new Scene(root));
			        secondStage.setTitle("Info");
			        secondStage.show();
					
				}else
				if(button.getTextFill().equals(Color.BLUE))//if buttons already been selected
				{
					//go to error pane
					errorMessage("ERROR: This option has already been selected.");
					return;
				}else
				{

					
				}
			}			
		});
	}
	
	public static void addEdge(int xP, int yP,int x, int y, Position<Vertex<Choice>> choice, int arrowPlacement)
	{	

		int posChange = 30;
		int midpointX = (xP+x+2*posChange)/2;
		int midpointY = (yP+y+2*posChange)/2;
		//System.out.println(xP +"-"+yP+"-"+x+"-"+y);
		//create line/edge from start to end
		Line line = new Line(xP+posChange, yP+posChange, x+posChange, y+posChange);
		Label lblWeight = new Label(""+choice.element().getWeight());
		lblWeight.setLayoutX(midpointX);
		lblWeight.setLayoutY(midpointY);
		lblWeight.setTextFill(Color.RED);
		//create directional arrow on line
		//Line arrowUp = new Line(x+15, y+25, x+30, y+30);
		//Line arrowDown = new Line(x+25, y+15, x+30, y+30);
		

		//if(xP != x && yP != y)
		{
			if(arrowPlacement > choice.element().getValue().getArrow())//upper bound
			{
				Polygon polygon = new Polygon();
		        polygon.getPoints().addAll(new Double[]{
		        		(double) (midpointX-15),(double) midpointY+10,
		        		(double) midpointX,(double) midpointY+15,
		        		(double) midpointX, (double) midpointY,
		        });

				pane.getChildren().add(polygon);

	
			}else
			if(arrowPlacement == choice.element().getValue().getArrow())//middle bound
			{

				Polygon polygon = new Polygon();
		        polygon.getPoints().addAll(new Double[]{
		        		(double) (midpointX-20),(double) midpointY-10,
		        		(double) midpointX,(double) midpointY,
		        		(double) midpointX-20, (double) midpointY+10,
		        });

				pane.getChildren().add(polygon);
				
			}else
			if(arrowPlacement < choice.element().getValue().getArrow())//lower bound
			{
				
				Polygon polygon = new Polygon();
		        polygon.getPoints().addAll(new Double[]{
		        		(double) (midpointX),(double) midpointY-20,
		        		(double) midpointX,(double) midpointY,
		        		(double) midpointX-20, (double) midpointY-10,
		        });

				pane.getChildren().add(polygon);
			}
		}
		//add line to pane
		//pane.getChildren().add(arrowUp);
		//pane.getChildren().add(arrowDown);
		pane.getChildren().add(line);
		pane.getChildren().add(lblWeight);
	}
	

	private static void displayNodes(Tree<Vertex<Choice>> tree, Position<Vertex<Choice>> choice) throws Exception 
	{
		
		Iterator<Position<Vertex<Choice>>> iterator = tree.getChildren(choice);

		if(tree.getParents(choice).get(0) == null)
		{
			choice.element().getValue().setX(0);
			choice.element().getValue().setY((int)scrollPane.getPrefHeight()/2);
			choice.element().getValue().setArrow(0);
			
			addNode(0, choice.element().getValue().getY(), choice);
		}
		
		while(iterator.hasNext())
		{

			Position<Vertex<Choice>> position = iterator.next();
			
			if(position.element().getValue().getDisplayed())
			{
				//System.out.println(position.toString() +"    ddddddd");
			}	
			else
			{
			
			//get depth which is the x axis
			int depth = tree.depth(tree, position);
			
			//calcuate y
			double numChild = tree.getNumChildren(tree.getParents(position).get(0));


			
			int parentChoice = 0;
			//determines how a child of one parents should look

			if(tree.getParents(position).size() == 1)
			{
				parentChoice = 0;
			}else
			if(tree.getParents(position).size() % 2 == 0)//determines how a child of many parents should look - if even
			{
					parentChoice = tree.getNumChildren(tree.getParents(position).get(0))/2;
					
				}else//determines how a child of many parents should look - if odd
				{
					
					parentChoice = (int)(tree.getNumChildren(tree.getParents(position).get(0))/2+0.5);
					
				}
				
				//this is the # in order ofwhen the child was added to a parent
				int childNum = position.element().getValue().getChildNum();
				if(numChild <= 1)
				{
					
					position.element().getValue().setY(root.element().getValue().getY());
					position.element().getValue().setArrow(0);
				}
				else
				if(numChild/2 >= childNum || childNum==1)//in lower bound of loop
				{
					
					//set above parent
					position.element().getValue().setY(tree.getParents(position).get(0).element().getValue().getY()-200/childNum);
					position.element().getValue().setArrow(-1);
					
				}else
				if(numChild/2 == childNum || numChild/2 == childNum-0.5)//at centre of loop
				{
	
					//set same as parent Y axis
					position.element().getValue().setY(tree.getParents(position).get(0).element().getValue().getY());
					position.element().getValue().setArrow(0);
	
				}else
				{
					if((numChild+1-childNum) <= 0)
					{
						//set below parent
						position.element().getValue().setY((int)(tree.getParents(position).get(0).element().getValue().getY()+200/(-numChild+1+childNum)));
						position.element().getValue().setArrow(1);
					}else
					{
						//set below parent
						position.element().getValue().setY((int)(tree.getParents(position).get(0).element().getValue().getY()+200/(numChild+1-childNum)));
						position.element().getValue().setArrow(1);
					}
					
					
				}
						
	

				
				position.element().getValue().setX(depth*100);

				
				//add nodes
				addNode(position.element().getValue().getX(), position.element().getValue().getY(),position);
				position.element().getValue().setDisplayed(true);

			}
			

			
			displayNodes(tree, position);
			
		}
		
	}
	
	
	
	private static void displayEdge(Tree<Vertex<Choice>> tree, Position<Vertex<Choice>> choice) throws Exception 
	{
		
		
		Iterator<Position<Vertex<Choice>>> iterator = tree.getChildren(choice);
		
		while(iterator.hasNext())
		{	
			Position<Vertex<Choice>> position = iterator.next();
			
			Iterator<Position<Vertex<Choice>>> iteratorC = tree.getChildren(position);
			//to add root
			if(tree.getParents(choice).get(0) == null)
			{

				addEdge(position.element().getValue().getX(),position.element().getValue().getY(),choice.element().getValue().getX(),choice.element().getValue().getY(),position,choice.element().getValue().getArrow());
			}
			
			while(iteratorC.hasNext())
			{		
				Position<Vertex<Choice>> c = iteratorC.next();
				addEdge(c.element().getValue().getX(),c.element().getValue().getY(),position.element().getValue().getX(),position.element().getValue().getY(),c,position.element().getValue().getArrow());
			}
			
				displayEdge(tree, position);
			
		}
		
	}

	static boolean searchResult;
	private static void searchParentVisited(Tree<Vertex<Choice>> tree, Position<Vertex<Choice>> choice, int id) throws Exception 
	{
		if(searchResult)
		{
			return;
		}
		Iterator<Position<Vertex<Choice>>> iterator = tree.getChildren(choice);
		//checks if root
		/*if(tree.getParents(choice).get(0) == null)
		{
			//checks if root is search id
			if(id == root.element().id)
			{
				searchResult = true;
				return;
			}
		}*/
		
		while(iterator.hasNext())
		{
			if(searchResult)
			{
				return;
			}
			
			if(id == root.element().getValue().getID())
			{
				searchResult = true;
				return;
			}

			Position<Vertex<Choice>> position = iterator.next();
			
			//checks if correct node is found
			
			
			
			if(id == position.element().getValue().getID())
			{
				

				//checks if parent node has been visited before

				for(Position<Vertex<Choice>> c : tree.getParents(position))
				{
					//searchResult = c.element().getVisited();

					if(c.element().getValue().getVisited())
					{
						searchResult = true;
						return;
					}
				}
				
			}
			
			searchParentVisited(tree, position, id);	
		}	
	}
	
	static boolean searchChildResult;
	private static void searchFellowChildVisited(Tree<Vertex<Choice>> tree, Position<Vertex<Choice>> choice, int id) throws Exception 
	{

		Iterator<Position<Vertex<Choice>>> iterator = tree.getChildren(choice);
		//checks if root
		if(tree.getParents(choice).get(0) == null)
		{
			//checks if root is search id
			if(id == root.element().getValue().getID())
			{
				//System.out.println("root found");
				searchChildResult = true;
				return;
			}
		}
		
		while(iterator.hasNext())
		{
			
			Position<Vertex<Choice>> position = iterator.next();
			//checks if correct node is found
			if(id == position.element().getValue().getID())
			{

				//goes over all children of that paren
				Iterator<Position<Vertex<Choice>>> iteratorChild = tree.getChildren(tree.getParents(position).get(0));
				
				while(iteratorChild.hasNext())
				{
					
					Position<Vertex<Choice>> positionChild = iteratorChild.next();
					//System.out.println(positionChild.element().getID() + "  "+ positionChild.element().getVisited());
					//if child visited, return false
					if(positionChild.element().getValue().getVisited())
					{
						searchChildResult = false;
						return;
					}
				}
					

				
			}
			
			searchFellowChildVisited(tree, position, id);	
		}	
		//System.out.println("failure");
		
	}

	
	private static void printChoices()
	{
		for(Position<Vertex<Choice>> p : vertexPath)
		{
			
			System.out.println(p.element().getValue().toString() + "\n");
		}
	}
	


	
	private static void shortestPath(Position<Vertex<Choice>> lastPosition) throws Exception
	{
		if(tree.getNumChildren(lastPosition) == 0)
		{
			return;
		}

		Iterator<Position<Vertex<Choice>>> iterator = tree.getChildren(lastPosition);
		Position<Vertex<Choice>> minPosition = iterator.next();
		
		double minWeight = minPosition.element().getWeight();
		
		while(iterator.hasNext())
		{
			Position<Vertex<Choice>> childPosition = iterator.next();
			
			if(childPosition.element().getWeight() < minWeight)
			{
				minPosition = childPosition;
				minWeight = minPosition.element().getWeight();
			}

		}
		
		addToPath(minPosition,searchButtonbyID(minPosition.element().getValue().getID()));
		shortestPath(minPosition);
		
	}
	
	
	private static void longestPath(Position<Vertex<Choice>> lastPosition) throws Exception
	{
		if(tree.getNumChildren(lastPosition) == 0)
		{
			return;
		}

		Iterator<Position<Vertex<Choice>>> iterator = tree.getChildren(lastPosition);
		
		Position<Vertex<Choice>> maxPosition = iterator.next();
		double maxWeight = maxPosition.element().getWeight();
		
		while(iterator.hasNext())
		{
			Position<Vertex<Choice>> childPosition = iterator.next();
			
			if(childPosition.element().getWeight() > maxWeight)
			{
				maxPosition = childPosition;
				maxWeight = maxPosition.element().getWeight();
			}

		}
		
		addToPath(maxPosition,searchButtonbyID(maxPosition.element().getValue().getID()));
		longestPath(maxPosition);
		
	}
	
	private static Button searchButtonbyID(int id)
	{
		for(Button b : listButtons)
		{
			if(Integer.parseInt(b.getText()) == (id))
			{
				return b;
			}
		}
		return null;
	}
	
	private static boolean canAfford(double newAmount)
	{
		double budget = 0;
		try
		{
			 budget = Double.parseDouble(txtBudget.getText());
		}catch(Exception e)
		{
			System.out.println("err");
		}
		
		if((total+newAmount) > budget)
		{
			return false;
		}
		
		return true;
	}
	
	private static void errorMessage(String error)
	{
		//go to error pane
		ErrorPane root = new ErrorPane(error, graphPane);
		Stage secondStage = new Stage();
		
		//secondStage.initStyle(StageStyle.UNDECORATED);
        secondStage.setScene(new Scene(root));
        secondStage.setTitle("Error");
        secondStage.show();
	}
	

	static String tempMaxString = "";
	static double tempMaxTotal = 0;
	
	private static void mostExpensiveAffordablePath(Tree<Vertex<Choice>> tree, Position<Vertex<Choice>> choice,double tempTotal, String tempString) throws Exception
	{
		Iterator<Position<Vertex<Choice>>> iterator = tree.getChildren(choice);


		tempTotal += choice.element().getWeight();
		tempString += choice.element().getValue().getID() + " ";
		//end of path
		if(tree.getNumChildren(choice) == 0)
		{
			System.out.println(tempString);
			if(canAfford(tempTotal))
			{
				if(tempTotal > tempMaxTotal)
				{
					tempMaxString = tempString;
					tempMaxTotal = tempTotal;
				}
				//check if new highest
			}
		}
		

		
		while(iterator.hasNext())
		{
			

			//counts at which child you are currently at	
			Position<Vertex<Choice>> position = iterator.next();
			mostExpensiveAffordablePath(tree, position, tempTotal,tempString);
			
		}
		
	}
	
	
	private static Position<Vertex<Choice>> getVertexByID(Tree<Vertex<Choice>> tree, Position<Vertex<Choice>> choice, int id, Position<Vertex<Choice>> found) throws Exception
	{
		Iterator<Position<Vertex<Choice>>> iterator = tree.getChildren(choice);


		
		while(iterator.hasNext())
		{
			//counts at which child you are currently at	
			Position<Vertex<Choice>> position = iterator.next();
			
			if(position.element().getValue().getID() == id)
			{
				found = position;
			}
			
			found = getVertexByID(tree, position, id, found);
			
		}
		return found;
		
	}
	
	private static void resetNodes()
	{
		int size = vertexPath.size();
		tempMaxString = "";
		tempMaxTotal = 0;
		for(int i = 0; i < size; i++)
		{
			goBack();
		}
	}
}
