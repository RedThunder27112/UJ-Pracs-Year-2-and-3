import java.sql.Time;
import java.util.ArrayList;

public class Choice
{

	private int id;
	private static int idCounter = 0;
	private boolean visited;
	private boolean displayed;
	private int x;
	private int y;
	private int childnumber = 0;
	private int arrow;
	
	
	private String name;
	private String description;
	private ArrayList<String> advantages = new ArrayList<String>();
	private ArrayList<String> disadvantages = new ArrayList<String>();
	private double monthlyRandCost;
	private int numMonths;
	private double totalRandCost;
	private int monthlyTimeCost;
	private int totalTimeCost;
	/**
	 * Name
	 * Description
	 * Advantages
	 * Disadvantages
	 * Monthly Cost
	 * Number Months
	 * Total Cost
	 * 
	 * Monthly Time Cost
	 * Total Time Cost
	 * 
	 */
	
	public Choice()
	{
		idCounter++;
		id = idCounter;
		setResults(id);
		visited = false;
	}
	
	public String getName()
	{
		return name;
	}
	
	public boolean getVisited()
	{
		return visited;
	}
	
	public void setVisited(boolean isVisit)
	{
		visited = isVisit;
	}
	
	public void setArrow(int arrow)
	{
		this.arrow = arrow;
	}
	
	public int getArrow()
	{
		return arrow;
	}
	
	public boolean getDisplayed()
	{
		return displayed;
	}
	
	public void setDisplayed(boolean isDisplay)
	{
		displayed = isDisplay;
	}
	
	
	public int getID()
	{
		return id;
	}

	public int getY()
	{
		return y;
	}

	public int getX()
	{
		return x;
	}
	
	
	public void setY(int y)
	{
		this.y = y;
	}
	
	public void setX(int x)
	{
		this.x = x;
	}
	
	public void setChildNum(int childnumber)
	{
		
		this.childnumber = childnumber;
	}
	
	public int getChildNum()
	{
		
		return childnumber;
	}
	
	public double getTotalRand()
	{
		return totalRandCost;
	}
	
	public double getTotalTime()
	{
		return totalTimeCost;
	}
	
	public String toString()
	{
		String display = "";
		display += "Name: " + name + "\n\n";
		display += "Description: " + description + "\n\n";
		
		if(!advantages.isEmpty())
		{
			display += "Advantages: " + "\n";
			
			int i = 0;
			for(String s : advantages)
			{
				i++;
				display += "Advantage " + i + " :" + s + "\n";
			}
			display += "\n";
			i = 0;
			display += "\nDisadvantages:: " + "\n";
			for(String s : disadvantages)
			{
				i++;
				display += "disadvantage " + i + " :" + s + "\n";
			}
			display += "\n";
			
			
			display += "Number of Months: " + numMonths + "\n\n";
			display += "Monthly Rand Cost: R" + monthlyRandCost + "\n\n";
			display += "Total Rand Cost: R" + totalRandCost + "\n\n";
			display += "Monthly Time Cost: " + monthlyTimeCost + "hrs\n\n";
			display += "Total Time Cost: " + totalTimeCost + "hrs\n\n";
		}
		
		
		return display;		
	}
	
	public void setResults(int choiceNum)
	{
		if(choiceNum == 1)
		{
			name = "Schooling";
			description = "Here a decision on what type of schooling you will send your child to, is made ";

		}else
		if(choiceNum == 2)
		{
			name = "Public School";
			description = "This is the middle ground in the terms of R cost.";
			advantages.add("A lot cheaper than private school");
			advantages.add("Fee excemption can occur for underprivledged families");
			
			disadvantages.add("Larger classes can result in your teachers not being able to give a lot of attention to each learner");
			disadvantages.add("tempAdvant 2");
			
			monthlyRandCost = 2500;
			monthlyTimeCost = 0;
			numMonths = 144;

			totalTimeCost = monthlyTimeCost*numMonths;
			totalRandCost = monthlyRandCost*numMonths;
		}else
		if(choiceNum == 3)
		{
			name = "Private School ";
			description = "This is the most expensive schooling option in R terms";
			advantages.add("Smaller classes lets teachers have more time for each student");
			advantages.add("tempAdvant 2");
				
			disadvantages.add("Very expensive");
			disadvantages.add("tempAdvant 2");
				
			monthlyRandCost = 10000;
			monthlyTimeCost = 0;
			numMonths = 144;

			totalTimeCost = monthlyTimeCost*numMonths;
			totalRandCost = monthlyRandCost*numMonths;
		}else
		if(choiceNum == 4)
		{
			name = "Home Schooling ";
			description = "Instead of going to a school, you can teach your child.";
			advantages.add("Little to no teaching/schooling costs");
			advantages.add("Get to spend a lot of time with your child");
				
			disadvantages.add("Get to spend a lot of time with your child");
			disadvantages.add("Uses a lot of your time");
				
			monthlyRandCost = 0;
			monthlyTimeCost = 20*5;
			numMonths = 144;

			totalTimeCost = monthlyTimeCost*numMonths;
			totalRandCost = monthlyRandCost*numMonths;
		}else
		if(choiceNum == 5)
		{
			name = "Private Home Tutoring";
			description = "Instead of going to a school, you can hire a private teacher(s) who will teach your child at home.";
			advantages.add("Your child will have 100% of the teachers focus");
			advantages.add("The class pace is set to match what your child knows.");
				
			disadvantages.add("Extremely expensive");
			disadvantages.add("Your child will not have any peer interactions like in a class, potentially resulting in not having friends");
				
			monthlyRandCost = 300*5*20;
			monthlyTimeCost = 0;
			numMonths = 144;

			totalTimeCost = monthlyTimeCost*numMonths;
			totalRandCost = monthlyRandCost*numMonths;
		}else
		if(choiceNum == 6)
		{
			name = "No Schooling";
			description = "Instead of going to a school, you don't.";
			advantages.add("No time or money cost");
			advantages.add("Can have your child help around with chores at home");
				
			disadvantages.add("Children by law have to go to school");
			disadvantages.add("Your child will not get an education that would help them secure a job in the future");
				
			monthlyRandCost = 0;
			monthlyTimeCost = -6*20;
			numMonths = 144;

			totalTimeCost = monthlyTimeCost*numMonths;
			totalRandCost = monthlyRandCost*numMonths;
		}
		else
		if(choiceNum == 7)
		{
			name = "Medical Aid";
			description = "Here is decision on if you want medical aid for your child";
		}
		else
		if(choiceNum == 8)
		{
			name = "Buy Medical Aid";
			description = "You decide that you want your child to have medical aid, jsut in case.";
			advantages.add("In a medical emergency, your child gets sick or if any chronic illnesses are found, your medical bills will be covoured");
			advantages.add("Private hospitals have less patients, so your child will be seen sooner");
				
			disadvantages.add("Very expensive");
				
			monthlyRandCost = 1500;
			monthlyTimeCost = 0;
			numMonths = 216;

			totalTimeCost = monthlyTimeCost*numMonths;
			totalRandCost = monthlyRandCost*numMonths;
		}
		else
		if(choiceNum == 9)
		{
			name = "No Medical Aid";
			description = "You decide that you don't want your child to have medical aid.";
			
			advantages.add("You will save a huge amount of money during your childs child years");

			disadvantages.add("You will have to pay out of pocket for any meds, hospital bills ect");
			disadvantages.add("Private hospitals have more patients, so waiting times are longer");
			
			monthlyRandCost = 0;
			monthlyTimeCost = 0;
			numMonths = 0;

			totalTimeCost = monthlyTimeCost*numMonths;
			totalRandCost = monthlyRandCost*numMonths;
		}
		else
		if(choiceNum == 10)
		{
			name = "Transport";
			description = "Here is decision on if how you want to get your child from place A to B. All calculations are done at R20/L and 100km/week";
			totalTimeCost = 0;
			totalRandCost = 0;
		}
		else
		if(choiceNum == 11)
		{
			name = "You drive them";
			description = "You personally drive your child. This will cost your time, and fuel money. Need a car for this option.";
			
			advantages.add("You get to spend more time with your child.");
			advantages.add("The fuel cost will not be very high");

			disadvantages.add("You need a car for this option");
			disadvantages.add("Need to get up earlier so as to not be late for work");
			disadvantages.add("School traffic is not fun");
			
			monthlyRandCost = 120*4;
			monthlyTimeCost = 15;
			numMonths = 12*12;

			totalTimeCost = monthlyTimeCost*numMonths;
			totalRandCost = monthlyRandCost*numMonths;
		}
		else
		if(choiceNum == 12)
		{
			name = "Uber";
			description = "You uber your child. This will save you time, but is quite expensive.";
			
			advantages.add("You don't use any of your own time");
			advantages.add("You don't have to take or fetch your child");

			disadvantages.add("Very expensive");
			disadvantages.add("Your child needs a phone for this");

			monthlyRandCost = 20*140;
			monthlyTimeCost = 0;
			numMonths = 12*12;

			totalTimeCost = monthlyTimeCost*numMonths;
			totalRandCost = monthlyRandCost*numMonths;
		}
		else
		if(choiceNum == 13)
		{
			name = "Lift Club";
			description = "You and some 3 other parents join together in a lift club. Each taking everyones children every fourth week.";
			
			advantages.add("You dont have to drive your child every week");
			advantages.add("Is cheaper and less time consuming than driving them yourself");

			disadvantages.add("The week you are driving, takes a lot more time that week");
			disadvantages.add("Must trust the other parents in group");

			monthlyRandCost = 240;
			monthlyTimeCost = 10;
			numMonths = 12*12;

			totalTimeCost = monthlyTimeCost*numMonths;
			totalRandCost = monthlyRandCost*numMonths;
		}
		else
		if(choiceNum == 14)
		{
			name = "Public Transport";
			description = "Your child can take public transport such as busses";
			
			advantages.add("You don't use any of your own time");
			advantages.add("Not very expensive, and your child can go far");

			disadvantages.add("Set bus routes");

			monthlyRandCost = 4*37;
			monthlyTimeCost = 0;
			numMonths = 12*12;

			totalTimeCost = monthlyTimeCost*numMonths;
			totalRandCost = monthlyRandCost*numMonths;
		}
		else
		if(choiceNum == 15)
		{
			name = "Walking";
			description = "Your child walks.";
			
			advantages.add("If your child is close, this makes the most sense.");
			advantages.add("No time or money cost involved");

			disadvantages.add("If you live far, your child will have to walk far every day");

			monthlyRandCost = 0;
			monthlyTimeCost = 0;
			numMonths = 12*12;

			totalTimeCost = monthlyTimeCost*numMonths;
			totalRandCost = monthlyRandCost*numMonths;
		}
		else
		{
			name = "tempName " + idCounter;
			description = "tempDesc " + idCounter;
			advantages.add("tempAdvant 1");
			advantages.add("tempAdvant 2");
			
			disadvantages.add("tempAdvant 1");
			disadvantages.add("tempAdvant 2");
			
			monthlyRandCost = idCounter*10;
			monthlyTimeCost = idCounter*15;
			numMonths = 2;

			totalTimeCost = monthlyTimeCost*numMonths;
			totalRandCost = monthlyRandCost*numMonths;
		}
		
		//possible
		//transport
		//medical aid

	}
	
	

	
	
	

}
