import com.jwetherell.algorithms.data_structures.Graph.Vertex;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

public class InfoPane extends GridPane
{
	public InfoPane(Position<Vertex<Choice>> elem, Button button,GraphPane graphPane)
	{
		BorderPane borderPane = new BorderPane();
		borderPane.setPrefSize(600, 600);
		
		VBox vBox = new VBox();
		vBox.setPrefSize(600, 600);
		
		
		ScrollPane scrollPane = new ScrollPane();
		scrollPane.setPrefSize(600, 600);
		//setting gridPane

		//setting labels
		Label lblOutput = new Label(elem.element().getValue().toString());
		
		//setting buttons
		Button btnYes = new Button("Yes");
		Button btnNo = new Button("No");
		btnYes.setPrefSize(100, 30);
		btnNo.setPrefSize(100, 30);
		
	
		//add nodes to pane
		scrollPane.setContent(lblOutput);
		borderPane.setLeft(btnYes);
		borderPane.setRight(btnNo);
		
		vBox.getChildren().add(scrollPane);
		vBox.getChildren().add(borderPane);
		this.getChildren().add(vBox);
		
		btnYes.setOnAction(new EventHandler <ActionEvent>()
		{
			
			@Override
			public void handle(ActionEvent event) 
			{	
				//add selection to path
				graphPane.addToPath(elem, button);
				//closes old window
				vBox.getScene().getWindow().hide();
				//opens main menu
				graphPane.setVisible(true);

			}			
		});
		
		btnNo.setOnAction(new EventHandler <ActionEvent>()
		{
			
			@Override
			public void handle(ActionEvent event) 
			{	

				//closes old window
				vBox.getScene().getWindow().hide();
				//opens main menu
				graphPane.setVisible(true);
			}			
		});
		
		
		
	}

}
