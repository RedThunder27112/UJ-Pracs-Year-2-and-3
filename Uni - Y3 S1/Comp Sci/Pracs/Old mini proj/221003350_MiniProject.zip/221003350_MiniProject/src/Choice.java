import java.sql.Time;
import java.util.ArrayList;

public class Choice
{

	private int id;
	private static int idCounter = 0;
	private boolean visited;
	private boolean displayed;
	private int x;
	private int y;
	private int childnumber = 0;
	private int arrow;
	
	
	private String name;
	private String description;
	private ArrayList<String> advantages = new ArrayList<String>();
	private ArrayList<String> disadvantages = new ArrayList<String>();
	private double monthlyRandCost;
	private int numMonths;
	private int totalRandCost;
	private double monthlyTimeCost;
	private int totalTimeCost;
	/**
	 * Name
	 * Description
	 * Advantages
	 * Disadvantages
	 * Monthly Cost
	 * Number Months
	 * Total Cost
	 * 
	 * Monthly Time Cost
	 * Total Time Cost
	 * 
	 */
	
	public Choice(/*String name, String description, */)
	{
		idCounter++;
		id = idCounter;
		name = "tempName";
		//this.name = name;
		//this.description = description;
		visited = false;
	
	}
	
	public String getName()
	{
		return name;
	}
	
	public boolean getVisited()
	{
		return visited;
	}
	
	public void setVisited(boolean isVisit)
	{
		visited = isVisit;
	}
	
	public void setArrow(int arrow)
	{
		this.arrow = arrow;
	}
	
	public int getArrow()
	{
		return arrow;
	}
	
	public boolean getDisplayed()
	{
		return displayed;
	}
	
	public void setDisplayed(boolean isDisplay)
	{
		displayed = isDisplay;
	}
	
	
	public int getID()
	{
		return id;
	}
	


	public int getY()
	{
		return y;
	}

	public int getX()
	{
		return x;
	}
	
	
	public void setY(int y)
	{
		this.y = y;
	}
	
	public void setX(int x)
	{
		this.x = x;
	}
	
	public void setChildNum(int childnumber)
	{
		
		this.childnumber = childnumber;
	}
	
	public int getChildNum()
	{
		
		return childnumber;
	}

	
	
	

}
