import com.jwetherell.algorithms.data_structures.Graph;
import com.jwetherell.algorithms.data_structures.Graph.Vertex;

public class ModifyTree
{
	Tree<Vertex<Choice>> tree;
	Position<Vertex<Choice>> root;
	
	public ModifyTree()
	{
		Choice c1 = new Choice();
		
		Graph.Vertex<Choice> v1 = new Graph.Vertex<Choice>(c1);
	
		
		tree = new Tree<Vertex<Choice>>(v1);
		root = tree.root();
		
		Choice c2 = new Choice();
		Choice c3 = new Choice();
		Choice c4 = new Choice();
		Choice c5 = new Choice();
		Choice c6 = new Choice();
		
		Choice c7 = new Choice();
		Choice c8 = new Choice();
		Choice c9 = new Choice();
		Choice c10 = new Choice();
		Choice c11 = new Choice();
		
		Graph.Vertex<Choice> v2 = new Graph.Vertex<Choice>(c2);
		Graph.Vertex<Choice> v3 = new Graph.Vertex<Choice>(c3);
		Graph.Vertex<Choice> v4 = new Graph.Vertex<Choice>(c4);
		Graph.Vertex<Choice> v5 = new Graph.Vertex<Choice>(c5);
		Graph.Vertex<Choice> v6 = new Graph.Vertex<Choice>(c6);
		Graph.Vertex<Choice> v7 = new Graph.Vertex<Choice>(c7);
		Graph.Vertex<Choice> v8 = new Graph.Vertex<Choice>(c8);
		Graph.Vertex<Choice> v9 = new Graph.Vertex<Choice>(c9);
		Graph.Vertex<Choice> v10 = new Graph.Vertex<Choice>(c10);
		Graph.Vertex<Choice> v11 = new Graph.Vertex<Choice>(c11);
		
		Position<Vertex<Choice>> a1;

			a1 = addNewChild(root, v2);
			Position<Vertex<Choice>> a2 = addNewChild(root, v3);
			Position<Vertex<Choice>> a3 = addNewChild(root, v4);
			Position<Vertex<Choice>> a4 = addNewChild(root, v5);
			Position<Vertex<Choice>> a5 = addNewChild(root, v6);

			Position<Vertex<Choice>> b1 = addNewChild(a1, v7);
			addExistingChild(a2, b1);
			addExistingChild(a3, b1);
			addExistingChild(a4, b1);
			addExistingChild(a5, b1);

			
			Position<Vertex<Choice>> d1 = addNewChild(b1, v8);
			Position<Vertex<Choice>> d2 = addNewChild(b1, v9);
			Position<Vertex<Choice>> d3 = addNewChild(b1, v10);
			
			Position<Vertex<Choice>> e1 = addNewChild(d1, v11);
			addExistingChild(d2, e1);
			addExistingChild(d3, e1);


	}
	
	public Position<Vertex<Choice>> addNewChild(Position<Vertex<Choice>> parent, Graph.Vertex<Choice> vertex)
	{
		try 
		{
			Position<Vertex<Choice>> child = tree.addElementAsChild(parent, vertex);
			
			child.element().addEdge(new Graph.Edge(5, vertex, parent.element()));
			child.element().setWeight(5);
			return child;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	
	public void addExistingChild(Position<Vertex<Choice>> parent,Position<Vertex<Choice>> child)
	{
		try 
		{
			tree.addExistChild(parent, child);
			child.element().addEdge(new Graph.Edge(6, child.element(), parent.element()));
			child.element().setWeight(6);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public Tree<Vertex<Choice>> getTree()
	{
		return tree;
	}
	
	public Position<Vertex<Choice>> getRoot()
	{
		return root;
	}
	
	

}
