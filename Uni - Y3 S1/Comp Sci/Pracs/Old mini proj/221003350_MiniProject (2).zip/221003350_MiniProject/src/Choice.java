import java.sql.Time;
import java.util.ArrayList;

public class Choice
{

	private int id;
	private static int idCounter = 0;
	private boolean visited;
	private boolean displayed;
	private int x;
	private int y;
	private int childnumber = 0;
	private int arrow;
	
	
	private String name;
	private String description;
	private ArrayList<String> advantages = new ArrayList<String>();
	private ArrayList<String> disadvantages = new ArrayList<String>();
	private double monthlyRandCost;
	private int numMonths;
	private double totalRandCost;
	private int monthlyTimeCost;
	private int totalTimeCost;
	/**
	 * Name
	 * Description
	 * Advantages
	 * Disadvantages
	 * Monthly Cost
	 * Number Months
	 * Total Cost
	 * 
	 * Monthly Time Cost
	 * Total Time Cost
	 * 
	 */
	
	public Choice(/*String name, String description, */)
	{
		
		idCounter++;
		id = idCounter;
		name = "tempName " + idCounter;
		description = "tempDesc " + idCounter;
		advantages.add("tempAdvant 1");
		advantages.add("tempAdvant 2");
		
		disadvantages.add("tempAdvant 1");
		disadvantages.add("tempAdvant 2");
		
		monthlyRandCost = idCounter*10;
		monthlyTimeCost = idCounter*15;
		numMonths = 2;

		totalTimeCost = monthlyTimeCost*numMonths;
		totalRandCost = monthlyRandCost*numMonths;
		//this.name = name;
		//this.description = description;
		visited = false;
	
	}
	
	public String getName()
	{
		return name;
	}
	
	public boolean getVisited()
	{
		return visited;
	}
	
	public void setVisited(boolean isVisit)
	{
		visited = isVisit;
	}
	
	public void setArrow(int arrow)
	{
		this.arrow = arrow;
	}
	
	public int getArrow()
	{
		return arrow;
	}
	
	public boolean getDisplayed()
	{
		return displayed;
	}
	
	public void setDisplayed(boolean isDisplay)
	{
		displayed = isDisplay;
	}
	
	
	public int getID()
	{
		return id;
	}
	


	public int getY()
	{
		return y;
	}

	public int getX()
	{
		return x;
	}
	
	
	public void setY(int y)
	{
		this.y = y;
	}
	
	public void setX(int x)
	{
		this.x = x;
	}
	
	public void setChildNum(int childnumber)
	{
		
		this.childnumber = childnumber;
	}
	
	public int getChildNum()
	{
		
		return childnumber;
	}
	
	public double getTotalRand()
	{
		return totalRandCost;
	}
	
	public String toString()
	{
		String display = "";
		display += "Name: " + name + "\n\n";
		display += "Description: " + description + "\n\n";
		display += "Advantages: " + "\n";
		
		int i = 0;
		for(String s : advantages)
		{
			i++;
			display += "Advantage " + i + " :" + s + "\n";
		}
		display += "\n";
		i = 0;
		for(String s : disadvantages)
		{
			i++;
			display += "disadvantage " + i + " :" + s + "\n";
		}
		display += "\n";
		
		
		display += "Number of Months: " + numMonths + "\n\n";
		display += "Monthly Rand Cost: R" + monthlyRandCost + "\n\n";
		display += "Total Rand Cost: R" + totalRandCost + "\n\n";
		display += "Monthly Time Cost: " + monthlyTimeCost + "hrs\n\n";
		display += "Total Time Cost: " + totalTimeCost + "hrs\n\n";
		
		return display;
		
		
	}

	
	
	

}
