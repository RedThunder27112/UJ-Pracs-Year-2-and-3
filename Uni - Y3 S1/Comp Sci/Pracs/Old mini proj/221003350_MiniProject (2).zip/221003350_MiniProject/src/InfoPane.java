import com.jwetherell.algorithms.data_structures.Graph.Vertex;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

public class InfoPane extends GridPane
{
	public InfoPane(Position<Vertex<Choice>> elem, Button button,GraphPane graphPane)
	{
		
		//setting gridPane
		GridPane gridPane = new GridPane();
		gridPane.setPrefSize(600, 600);
		
		//setting labels
		Label lblOutput = new Label(elem.element().getValue().toString());
		
		//setting buttons
		Button btnYes = new Button("Yes");
		Button btnNo = new Button("No");
		btnYes.setPrefSize(100, 30);
		btnNo.setPrefSize(100, 30);
		
	
		//add nodes to pane
		gridPane.add(lblOutput, 0, 0);//col row
		gridPane.add(btnYes, 0, 1);//col row
		gridPane.add(btnNo, 1, 1);//col row
		
		this.getChildren().add(gridPane);
		
		btnYes.setOnAction(new EventHandler <ActionEvent>()
		{
			
			@Override
			public void handle(ActionEvent event) 
			{	
				//add selection to path
				graphPane.addToPath(elem, button);
				//closes old window
				gridPane.getScene().getWindow().hide();
				//opens main menu
				graphPane.setVisible(true);
				//elem.element().getValue().setVisited(true);
				//borderPane.setVisible(true);
		        //button.setTextFill(Color.BLUE);
		        //button.setStyle("-fx-background-color: BLUE");
			}			
		});
		
		
		
	}

}
