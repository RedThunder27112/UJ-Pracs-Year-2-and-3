

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;
import java.util.StringTokenizer;

import com.jwetherell.algorithms.data_structures.Graph;
import com.jwetherell.algorithms.data_structures.Graph.Edge;
import com.jwetherell.algorithms.data_structures.Graph.Vertex;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextArea;
import javafx.scene.input.MouseDragEvent;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Line;
import javafx.scene.shape.Polygon;
import javafx.scene.shape.Shape;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

public class GraphPane extends StackPane
{
	static Pane pane;
	static int total;
	static int totalTime;
	static TextArea txtTotal;
	static TextArea txtBudget;
	static GridPane gridPane;
	static GraphPane graphPane;
	static Vertex<Choice> root;
	static ScrollPane scrollPane;
	
	static ArrayList<Vertex<Choice>> vertexPath = new ArrayList<Vertex<Choice>>();
	static ArrayList<Button> choicePath = new ArrayList<Button>();
	static ArrayList<Button> listButtons = new ArrayList<Button>();
	static int choiceNumber = -1;
	static boolean longPath = false;
	
	
	public GraphPane()
	{
		
		graphPane = this;
		gridPane = new GridPane();
		//setting vbox/controls
		VBox vbox = new VBox();
		vbox.setPrefSize(1200, 800);
		//setting pane/graph
		pane = new Pane();
		pane.setPrefSize(USE_COMPUTED_SIZE, USE_COMPUTED_SIZE);
		
		//scrollpane
		scrollPane = new ScrollPane();
		scrollPane.setContent(pane);
		scrollPane.setPrefSize(600, 600);
		//adding both to main borderpane for layout



		
		//adding controls to vbox
		Label lblTotal = new Label("Current Total:");
		txtTotal = new TextArea();
		txtTotal.setPrefSize(getPrefWidth(), 30);
		
		Label lblBudget = new Label("Please Enter Your Total Budget Here:");
		txtBudget = new TextArea();
		txtBudget.setPrefSize(getPrefWidth(), 20);
		
		//add buttons
		
		Button btnGoBack = new Button("Go Back One Choice");
		btnGoBack.setPrefSize(200, 30);
		
		Button btnReset = new Button("Reset Choices");
		btnReset.setPrefSize(200, 30);
		
		Button btnDisplayChoices = new Button("Display Current Choices Info");
		btnDisplayChoices.setPrefSize(200, 30);
		
		Button btnShortPath = new Button("Shortest Path");
		btnShortPath.setPrefSize(200, 30);
		
		Button btnLongPath= new Button("Longest Path (Money is no issue)");
		btnLongPath.setPrefSize(200, 30);

		Button btnExpensiveAffordable = new Button("Most expensive path you can afford");
		btnExpensiveAffordable.setPrefSize(200, 30);

		
		gridPane.add(lblTotal, 0, 0);
		gridPane.add(txtTotal, 0, 1);
		gridPane.add(lblBudget, 0, 2);
		gridPane.add(txtBudget, 0, 3);
		gridPane.add(btnGoBack, 0, 4);
		gridPane.add(btnReset, 1, 0);
		gridPane.add(btnExpensiveAffordable, 1, 1);
		gridPane.add(btnShortPath, 1, 2);
		gridPane.add(btnLongPath, 1, 3);
		gridPane.add(btnDisplayChoices, 1, 4);
		
		vbox.getChildren().add(gridPane);
		vbox.getChildren().add(scrollPane);
		
		this.getChildren().add(vbox);
		
		//generate tree and fill it
		ModifyTree modifyTree = new ModifyTree();
		
		//tree = modifyTree.getTree();
		root = modifyTree.getRoot().element();
		
		try 
		{

			
			displayNodes(root);
			displayEdge(root);
			//System.out.println(tree.preOrderElementTraversal(tree, root));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		//set buttons actipns
		
		btnGoBack.setOnAction(new EventHandler <ActionEvent>()
		{
			@Override
			public void handle(ActionEvent event) 
			{
				goBack();
			}		
		});
		
		btnReset.setOnAction(new EventHandler <ActionEvent>()
		{
			@Override
			public void handle(ActionEvent event) 
			{
				resetNodes();
			}		
		});
		
		btnDisplayChoices.setOnAction(new EventHandler <ActionEvent>()
		{
			@Override
			public void handle(ActionEvent event) 
			{

				printChoices();
				graphPane.setVisible(false);
				//opens main menu
				ResultsPane root = new ResultsPane(vertexPath, graphPane);
				Stage secondStage = new Stage();
				
				//secondStage.initStyle(StageStyle.UNDECORATED);
		        secondStage.setScene(new Scene(root));
		        secondStage.setTitle("Results");
		        secondStage.show();
			}		
		});
		
		btnShortPath.setOnAction(new EventHandler <ActionEvent>()
		{
			@Override
			public void handle(ActionEvent event) 
			{
				longPath = true;
				resetNodes();
				try {
					if(vertexPath.isEmpty())
					{
						addToPath(root, listButtons.get(0));
					}
					shortestPath(vertexPath.get(choiceNumber));
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				longPath = false;

			}		
		});
		
		btnLongPath.setOnAction(new EventHandler <ActionEvent>()
		{
			@Override
			public void handle(ActionEvent event) 
			{
				longPath = true;
				resetNodes();

				try {
					if(vertexPath.isEmpty())
					{
						addToPath(root, listButtons.get(0));
					}
					longestPath(vertexPath.get(choiceNumber));
				} catch (Exception e) 
				{
					e.printStackTrace();
				}
				longPath = false;

			}		
		});

		
		btnExpensiveAffordable.setOnAction(new EventHandler <ActionEvent>()
		{
			@Override
			public void handle(ActionEvent event) 
			{

				longPath = true;
				try {

					resetNodes();
					mostExpensiveAffordablePath(root, 0, "");

					StringTokenizer st = new StringTokenizer(tempMaxString);
					while(st.hasMoreTokens())
					{
						int id = Integer.parseInt(st.nextToken());

						Vertex<Choice>  vertex = getVertexByID(root,id,root);
						addToPath(vertex,searchButtonbyID(vertex.getValue().getID()));
					}
					
					if(tempMaxString.length() < 1)
					{
						//resetNodes();
						errorMessage("ERROR: There is no possible path that is affordable with the current budget");
					}

					//System.out.println("Most: "+ tempMaxTotal);
					//System.out.println("Most S : "+ tempMaxString);
					
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				longPath = false;
				 

			}		
		});

		////
		
	}
	
	public static void goBack()
	{
		
		//if choice exists
		if(choiceNumber > -1)
		{
			//go back one on button
			Button button = choicePath.get(choiceNumber);
			button.setTextFill(null);
			button.setStyle("-fx-background-color: BLACK");

			//go back on 
			Vertex<Choice> vertex = vertexPath.get(choiceNumber);
			vertex.getValue().setDisplayed(false);
			vertex.getValue().setVisited(false);
			
			//now get rid of button and vertex from list
			vertexPath.remove(choiceNumber);
			choicePath.remove(choiceNumber);
			
			total -= vertex.getWeight();
			totalTime -= vertex.getValue().getTotalTime();
			txtTotal.setText("Money: R"+total+"\nTime: "+totalTime);
			
			choiceNumber--;
			
			
			
			
		}else
		{
			errorMessage("ERROR: There is no node selected to undo.");
			return;
		}

	}
	
	public static void addToPath(Vertex<Choice> elem,Button button)
	{
		if(longPath)
		{	
		}else
		if(!canAfford(elem.getWeight()))
		{
			errorMessage("ERROR: You cannot afford this choice.");
			return;
		}
		
		
		elem.getValue().setVisited(true);
        button.setTextFill(Color.BLUE);
        button.setStyle("-fx-background-color: BLUE");
        
		vertexPath.add(elem);
		choicePath.add(button);
		choiceNumber++;
		
		total += elem.getWeight();
		totalTime += elem.getValue().getTotalTime();
		txtTotal.setText("Money: R"+total+"\nTime: "+totalTime+"hrs");
		
	}
	
	final static int nodeSize = 50;
	final static int edgeSize = 50;
	public static void addNode(int x, int y, Vertex<Choice> elem)
	{

		Button button = new Button(""+elem.getValue().getID());
		button.setShape(new Circle(10));
		button.setPrefSize(nodeSize,nodeSize);
		button.setLayoutX(x);
		button.setLayoutY(y);
		button.setTextFill(null);
		button.setStyle("-fx-background-color: BLACK");
		
		Label lblName = new Label(elem.getValue().getName());
		lblName.setLayoutX(x);
		lblName.setLayoutY(y-15);
		
		listButtons.add(button);
		
		pane.getChildren().add(lblName);
		pane.getChildren().add(button);
		

		button.setOnAction(new EventHandler <ActionEvent>()
		{
			
			@Override
			public void handle(ActionEvent event) 
			{

				txtTotal.setText("Money: R"+total+"\nTime: "+totalTime+"hrs");
				
				
				//if parent not visited yet
				if(!correctPath(elem))
				{
					//go to error pane
					errorMessage("ERROR: The graph is directed. You can only choose a child node of the last choice you made.");
			        return;
					
				}else
				if(button.getTextFill() == null)//if button viable
				{
					graphPane.setVisible(false);
					//opens main menu
					InfoPane root = new InfoPane(elem, button, graphPane);
					Stage secondStage = new Stage();
					
					//secondStage.initStyle(StageStyle.UNDECORATED);
			        secondStage.setScene(new Scene(root));
			        secondStage.setTitle("Info");
			        secondStage.show();
					
				}else
				if(button.getTextFill().equals(Color.BLUE))//if buttons already been selected
				{
					//go to error pane
					errorMessage("ERROR: This option has already been selected.");
					return;
				}else
				{
					
					
				}
			}			
		});
	}
	

	
	public static void addEdge(int xP, int yP,int x, int y, Vertex<Choice> choice, int arrowPlacement)
	{
		
		int posChange = 30;
		int midpointX = (xP+x+2*posChange)/2;
		int midpointY = (yP+y+2*posChange)/2;
		//System.out.println(xP +"-"+yP+"-"+x+"-"+y);
		//create line/edge from start to end
		Line line = new Line(xP+posChange, yP+posChange, x+posChange, y+posChange);
		Label lblWeight = new Label(""+choice.getWeight());
		lblWeight.setLayoutX(midpointX);
		lblWeight.setLayoutY(midpointY);
		lblWeight.setTextFill(Color.RED);
		//create directional arrow on line
		//Line arrowUp = new Line(x+15, y+25, x+30, y+30);
		//Line arrowDown = new Line(x+25, y+15, x+30, y+30);
		

		//if(xP != x && yP != y)
		{
			if(arrowPlacement > choice.getValue().getArrow())//upper bound
			{
				Polygon polygon = new Polygon();
		        polygon.getPoints().addAll(new Double[]{
		        		(double) (midpointX-15),(double) midpointY+10,
		        		(double) midpointX,(double) midpointY+15,
		        		(double) midpointX, (double) midpointY,
		        });

				pane.getChildren().add(polygon);

	
			}else
			if(arrowPlacement == choice.getValue().getArrow())//middle bound
			{

				Polygon polygon = new Polygon();
		        polygon.getPoints().addAll(new Double[]{
		        		(double) (midpointX-20),(double) midpointY-10,
		        		(double) midpointX,(double) midpointY,
		        		(double) midpointX-20, (double) midpointY+10,
		        });

				pane.getChildren().add(polygon);
				
			}else
			if(arrowPlacement < choice.getValue().getArrow())//lower bound
			{
				
				Polygon polygon = new Polygon();
		        polygon.getPoints().addAll(new Double[]{
		        		(double) (midpointX),(double) midpointY-20,
		        		(double) midpointX,(double) midpointY,
		        		(double) midpointX-20, (double) midpointY-10,
		        });

				pane.getChildren().add(polygon);
			}
		}
		//add line to pane
		//pane.getChildren().add(arrowUp);
		//pane.getChildren().add(arrowDown);
		pane.getChildren().add(line);
		pane.getChildren().add(lblWeight);
	}
	


	public static Integer depth(Vertex<Choice> parentPosition) 
	{
		
		//get the TreeNodes parent

		//if root = 0
		if(parentPosition == root)
		{
			return 0;
			
		}else
		{
			Vertex<Choice> parent = null;
			try 
			{
				//get parent
				List<Edge<Choice>> listE = parentPosition.getEdges();
				
				
				parent = listE.get(0).getFromVertex();

			} catch (Exception e) {
				
			}
			
			//get parents detph + 1
			return 1 + depth(parent);
			
		}
	}
	
	private static void displayNodes(Vertex<Choice> choice) throws Exception 
	{	
		
		if(choice.equals(root))
		{

			choice.getValue().setX(0);
			choice.getValue().setY((int)scrollPane.getPrefHeight()/2);
			choice.getValue().setArrow(0);
			
			addNode(0, choice.getValue().getY(), choice);
		}

	
		
		
		Iterator<Vertex<Choice>> iterator = getChildren(choice).iterator();
		
		
		

		
		while(iterator.hasNext())
		{
			Vertex<Choice> position = iterator.next();
			
		

			
			if(position.getValue().getDisplayed())
			{
				//System.out.println(position.toString() +"    ddddddd");
			}	
			else
			{
			
				//get depth which is the x axis
				int depth = depth(position);
				//calcuate y
				

				

				
				double numChild = getNumFellowChildren(position);
	
				
				//this is the # in order ofwhen the child was added to a parent
				int childNum = position.getValue().getChildNum();
				
				
	
				
				
				if(numChild <= 1)
				{
					
					position.getValue().setY(root.getValue().getY());
					position.getValue().setArrow(0);
				}
				else
				if(numChild/2 >= childNum || childNum==1)//in lower bound of loop
				{
					
					//set above parent
					position.getValue().setY(getParent(position).getValue().getY()-200/childNum);
					position.getValue().setArrow(-1);
					
				}else
				if(numChild/2 == childNum || numChild/2 == childNum-0.5)//at centre of loop
				{
					//set same as parent Y axis
					position.getValue().setY(getParent(position).getValue().getY());
					position.getValue().setArrow(0);
	
				}else
				{
					if((numChild+1-childNum) <= 0)
					{
						//set below parent
						position.getValue().setY((int)(getParent(position).getValue().getY()+200/(-numChild+1+childNum)));
						position.getValue().setArrow(1);
					}else
					{
						//set below parent
						position.getValue().setY((int)(getParent(position).getValue().getY()+200/(numChild+1-childNum)));
						position.getValue().setArrow(1);
					}
				}
						
				position.getValue().setX(depth*100);
				
				//add nodes
				
				addNode(position.getValue().getX(), position.getValue().getY(),position);
				position.getValue().setDisplayed(true);
				

			}
			

			
			displayNodes(position);

		}
	}
	
	private static Vertex<Choice> getParent(Vertex<Choice> child)
	{
		List<Edge<Choice>> listC = child.getEdges();
		for(Edge<Choice> pp : listC)
		{

			if(child.getValue().getID() != pp.getFromVertex().getValue().getID())
			{
				return pp.getFromVertex();
			}
		}
		return null;
	}
	
	private static int getNumFellowChildren(Vertex<Choice> child)
	{
		Vertex<Choice> parent = getParent(child);

		//calc num child
		List<Edge<Choice>> listC = parent.getEdges();

		int numChild = 0;
		for(Edge<Choice> pp : listC)
		{
			if(parent.getValue().getID() != pp.getToVertex().getValue().getID())
			{

				numChild++;
			}
		}
		
		return numChild;
		
	}
			

			
			
	private static boolean correctPath(Vertex<Choice> newChoice)
	{
		if(choiceNumber == -1) { return true;}
		if(vertexPath.get(choiceNumber).pathTo(newChoice))
		{
			return true;
		}
		
		return false;
	}
	
	
 	private static void displayEdge(Vertex<Choice> choice) throws Exception 
	{
		 
		/*
		Iterator<Edge<Choice>> iterator = choice.getEdges().iterator();
		

		
		while(iterator.hasNext())
		{
			Edge<Choice> p = iterator.next();
			
			Vertex<Choice> position = p.getToVertex();
			
			boolean end = true;
			while(position.getValue().getID() == choice.getValue().getID() && end)
			{
				if(iterator.hasNext())
				{
					p = iterator.next();
					position = p.getToVertex();
				}else
				{
					end = false;
				}
			}
			


			if(position.getValue().getID() == choice.getValue().getID())
			{
				return;
			}
			addEdge(position.getValue().getX(),position.getValue().getY(),choice.getValue().getX(),choice.getValue().getY(),position,choice.getValue().getArrow());
			displayEdge(position);
		}
	*/

			
		Iterator<Vertex<Choice>> iterator = getChildren(choice).iterator();
		
		while(iterator.hasNext())
		{	
			Vertex<Choice> position = iterator.next();
			
			Iterator<Vertex<Choice>> iteratorC = getChildren(position).iterator();
			//to add root
			if(choice == root)
			{

				addEdge(position.getValue().getX(),position.getValue().getY(),choice.getValue().getX(),choice.getValue().getY(),position,choice.getValue().getArrow());
			}
			
			while(iteratorC.hasNext())
			{		
				Vertex<Choice> c = iteratorC.next();
				addEdge(c.getValue().getX(),c.getValue().getY(),position.getValue().getX(),position.getValue().getY(),c,position.getValue().getArrow());
			}
			
				displayEdge(position);
			
		}
			
		
		
	}
	
	
	private static void printChoices()
	{
		for(Vertex<Choice> p : vertexPath)
		{
			
			System.out.println(p.getValue().toString() + "\n");
		}
	}
	


	
	private static void shortestPath(Vertex<Choice> lastPosition) throws Exception
	{
		if(getNumChildren(lastPosition) == 0)
		{
			return;
		}

		Iterator<Vertex<Choice>> iterator = getChildren(lastPosition).iterator();
		Vertex<Choice> minPosition = iterator.next();
		
		double minWeight = minPosition.getWeight();
		
		while(iterator.hasNext())
		{
			Vertex<Choice> childPosition = iterator.next();
			
			if(childPosition.getWeight() < minWeight)
			{
				minPosition = childPosition;
				minWeight = minPosition.getWeight();
			}

		}
		
		addToPath(minPosition,searchButtonbyID(minPosition.getValue().getID()));
		shortestPath(minPosition);
		
	}
	
	private static int getNumChildren(Vertex<Choice> vertex)
	{
		List<Edge<Choice>> listC = vertex.getEdges();

		int numChild = 0;
		for(Edge<Choice> pp : listC)
		{
			if(vertex.getValue().getID() != pp.getToVertex().getValue().getID())
			{

				numChild++;
			}
		}
		
		return numChild;
	}
	
	private static ArrayList<Vertex<Choice>> getChildren(Vertex<Choice> vertex)
	{
		ArrayList<Vertex<Choice>> children = new ArrayList<Vertex<Choice>>();
		List<Edge<Choice>> listC = vertex.getEdges();

		for(Edge<Choice> pp : listC)
		{
			if(vertex.getValue().getID() != pp.getToVertex().getValue().getID())
			{
				children.add(pp.getToVertex());

			}
		}
		
		return children;
	}
	
	
	private static void longestPath(Vertex<Choice> lastPosition) throws Exception
	{
		if(getNumChildren(lastPosition) == 0)
		{
			return;
		}

		Iterator<Vertex<Choice>> iterator = getChildren(lastPosition).iterator();
		
		Vertex<Choice> maxPosition = iterator.next();
		double maxWeight = maxPosition.getWeight();
		
		while(iterator.hasNext())
		{
			Vertex<Choice> childPosition = iterator.next();
			
			if(childPosition.getWeight() > maxWeight)
			{
				maxPosition = childPosition;
				maxWeight = maxPosition.getWeight();
			}

		}
		
		addToPath(maxPosition,searchButtonbyID(maxPosition.getValue().getID()));
		longestPath(maxPosition);
		
	}
	
	
	private static Button searchButtonbyID(int id)
	{
		for(Button b : listButtons)
		{
			if(Integer.parseInt(b.getText()) == (id))
			{
				return b;
			}
		}
		return null;
	}
	
	private static boolean canAfford(double newAmount)
	{
		double budget = 0;
		try
		{
			 budget = Double.parseDouble(txtBudget.getText());
		}catch(Exception e)
		{
			System.out.println("err");
		}
		
		if((total+newAmount) > budget)
		{
			return false;
		}
		
		return true;
	}
	

	

	static String tempMaxString = "";
	static double tempMaxTotal = 0;
	
	private static void mostExpensiveAffordablePath(Vertex<Choice> choice,double tempTotal, String tempString) throws Exception
	{
		Iterator<Vertex<Choice>> iterator = getChildren(choice).iterator();


		tempTotal += choice.getWeight();
		tempString += choice.getValue().getID() + " ";
		//end of path
		if(getNumChildren(choice) == 0)
		{

			if(canAfford(tempTotal))
			{
				if(tempTotal > tempMaxTotal)
				{
					tempMaxString = tempString;
					tempMaxTotal = tempTotal;
				}
				//check if new highest
			}
		}
		

		
		while(iterator.hasNext())
		{
			

			//counts at which child you are currently at	
			Vertex<Choice> position = iterator.next();
			mostExpensiveAffordablePath(position, tempTotal,tempString);
			
		}
		
	}
	
	
	private static Vertex<Choice> getVertexByID(Vertex<Choice> choice, int id, Vertex<Choice> found) throws Exception
	{
		Iterator<Vertex<Choice>> iterator = getChildren(choice).iterator();


		
		while(iterator.hasNext())
		{
			//counts at which child you are currently at	
			Vertex<Choice> position = iterator.next();
			
			if(position.getValue().getID() == id)
			{
				found = position;
			}
			
			found = getVertexByID(position, id, found);
			
		}
		return found;
		
	}
	
	private static void resetNodes()
	{
		int size = vertexPath.size();
		tempMaxString = "";
		tempMaxTotal = 0;
		for(int i = 0; i < size; i++)
		{
			goBack();
		}
	}
	
	private static void errorMessage(String error)
	{
		//go to error pane
		ErrorPane root = new ErrorPane(error, graphPane);
		Stage secondStage = new Stage();
		
		//secondStage.initStyle(StageStyle.UNDECORATED);
	    secondStage.setScene(new Scene(root));
	    secondStage.setTitle("Error");
	    secondStage.show();
	}
}
