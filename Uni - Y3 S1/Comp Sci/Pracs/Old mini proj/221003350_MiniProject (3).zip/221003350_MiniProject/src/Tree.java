
import java.util.ArrayList;
import java.util.Iterator;
import com.jwetherell.algorithms.data_structures.Graph.Vertex;

public class Tree<T>
{
	private TreeNode<T> root = null;
	private int size = 0;
	
	public Tree(T element) 
	{
		root = new TreeNode<T>(null, element);
	}
	

	public Position<T> getRoot() 
	{
		return root;
	}
	


	public Iterator<Position<T>> getChildren(Position<T> parentPosition) throws Exception 
	{
		return positionToTreeNode(parentPosition).getChildren();
	}

	
	public ArrayList<Position<T>> getParents(Position<T> childPosition) throws Exception {
		
		TreeNode<T> treeNode = positionToTreeNode(childPosition);
		
		ArrayList<Position<T>> parentArray = new ArrayList<Position<T>>();
		
		for(TreeNode<T> t : treeNode.getParents())
		{
			parentArray.add(t);
		}
		return parentArray;
	}
	
	public int getNumChildren(Position<T> parentPosition)
	{
		try 
		{
			return positionToTreeNode(parentPosition).getNumChildren();
		} catch (Exception e) {
		}
		return -1;
	}
	

	
	public Position<T> addNewChild(Position<T> parentPosition, T element) throws Exception 
	{
				
		TreeNode<T> child = positionToTreeNode(parentPosition).addChild(element);
		
		Vertex<Choice> cChild = (Vertex<Choice>) child.element();
		cChild.getValue().setChildNum(positionToTreeNode(parentPosition).getNumChildren());
		size++;
		return child;
	}
	
	public Position<T> addExistChild(Position<T> parentPosition, Position<T> childPosition) throws Exception 
	{
		TreeNode<T> parent = positionToTreeNode(parentPosition);
		TreeNode<T> child = positionToTreeNode(childPosition);
		Vertex<Choice> cChild = (Vertex<Choice>) child.element();
		cChild.getValue().setChildNum(parent.getNumChildren());
		parent.addExistingChild(child,parent);
		size++;
		return child;
	}
	

	

	private TreeNode<T> positionToTreeNode(Position<T> position) throws Exception 
	{
		if (position instanceof TreeNode<T>) 
		{
			return (TreeNode<T>) position;
		}
		return null;
	}


	
	public Integer depth(Tree<T> tree, Position<T> parentPosition) 
	{
		//get the TreeNodes parent
		Position<T> parent = null;
		try 
		{
			//get parent
			parent = getParents(parentPosition).get(0);//get the first parent in the lsit, as the length of them all is the same
		} catch (Exception e) {
			
		}
		//if root = 0
		if(parent == null)
		{
			return 0;
		}else
		{
			//get parents detph + 1
			return 1 + depth(tree, parent);
			
		}
	}
	

}
