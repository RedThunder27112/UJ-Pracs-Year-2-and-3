There is a runnable .jar in docs. (This does require javaFX arguments to be added in CMD when running)
(Arguments:
java --module-path "C:\javafx-17\lib" --add-modules javafx.base,javafx.controls,javafx.fxml,javafx.graphics,javafx.media -jar "docs\Runnable.jar"

Location to run: Same location as 221003350_MiniPorject. ie Before docs or src folder

OR

There is a batch file "RunJar" in 221003350_MiniProject folder with above command

OR

For ease of use, there is a batch file which containes arguments to run program. (In docs as well)

