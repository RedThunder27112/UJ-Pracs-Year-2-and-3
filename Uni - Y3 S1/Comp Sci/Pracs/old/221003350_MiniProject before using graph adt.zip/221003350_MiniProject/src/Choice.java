
public class Choice 
{
	String name;
	String description;
	int id;
	int weight;
	static int idCounter = 0;
	boolean visited;
	boolean displayed;
	int x;
	int y;
	int childnumber = 0;
	
	public Choice(/*String name, String description, */)
	{
		idCounter++;
		id = idCounter;
		weight = idCounter*3;
		
		//this.name = name;
		//this.description = description;
		visited = false;
	
	}
	
	public boolean getVisited()
	{
		return visited;
	}
	
	public void setVisited()
	{
		visited = true;
	}
	
	public boolean getDisplayed()
	{
		return displayed;
	}
	
	public void setDisplayed()
	{
		displayed = true;
	}
	
	
	public int getID()
	{
		return id;
	}
	
	public int getWeight()
	{
		return weight;
	}
	

	public int getY()
	{
		return y;
	}

	public int getX()
	{
		return x;
	}
	
	
	public void setY(int y)
	{
		this.y = y;
	}
	
	public void setX(int x)
	{
		this.x = x;
	}
	
	public void setChildNum(int childnumber)
	{
		
		this.childnumber = childnumber;
	}
	
	public int getChildNum()
	{
		
		return childnumber;
	}
	
	
	

}
