

import java.util.ArrayList;
import java.util.Iterator;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextArea;
import javafx.scene.input.MouseDragEvent;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Line;
import javafx.scene.shape.Shape;
import javafx.stage.Stage;

public class GraphPane extends StackPane
{
	static Pane pane;
	static int total;
	static TextArea txtTotal;
	static TextArea txtDisplay;
	static GridPane gridPane;
	static GraphPane graphPane;
	static Tree<Choice> tree;
	static Position<Choice> root;
	static ScrollPane scrollPane;
	
	public GraphPane()
	{
		
		graphPane = this;
		gridPane = new GridPane();
		//setting vbox/controls
		VBox vbox = new VBox();
		vbox.setMaxSize(200, 200);
		//setting pane/graph
		pane = new Pane();
		pane.setPrefSize(2000, 2000);
		
		//scrollpane
		scrollPane = new ScrollPane();
		scrollPane.setContent(pane);
		scrollPane.setPrefSize(600, 600);
		//adding both to main borderpane for layout
		gridPane.add(vbox, 0, 0);
		gridPane.add(scrollPane, 0, 1);

		
		//adding controls to vbox
		Label lblTotal = new Label("Total:");
		txtTotal = new TextArea();
		txtTotal.setPrefSize(getPrefWidth(), 20);
		
		Label lblDisplay = new Label("Display:");
		txtDisplay = new TextArea();
		txtDisplay.setPrefSize(getPrefWidth(), 20);
		
		vbox.setPadding(getInsets());
		
		vbox.getChildren().add(lblTotal);
		vbox.getChildren().add(txtTotal);
		vbox.getChildren().add(lblDisplay);
		vbox.getChildren().add(txtDisplay);
		

		this.getChildren().add(gridPane);
		Choice c1 = new Choice();
		tree = new Tree<Choice>(c1);
		root = tree.root();
		try 
		{
			Choice c2 = new Choice();
			Choice c3 = new Choice();
			Choice c4 = new Choice();
			Choice c5 = new Choice();
			Choice c6 = new Choice();
			
			Choice c7 = new Choice();
			Choice c8 = new Choice();
			Choice c9 = new Choice();
			Choice c10 = new Choice();
			Choice c11 = new Choice();
			//Choice c6 = new Choice();
			
			Position<Choice> a1 = tree.addElementAsChild(root, c2);
			Position<Choice> a2 = tree.addElementAsChild(root, c3);
			Position<Choice> a3 = tree.addElementAsChild(root, c4);
			Position<Choice> a4 = tree.addElementAsChild(root, c5);
			Position<Choice> a5 = tree.addElementAsChild(root, c6);
			//Position<Choice> a4 = tree.addElementAsChild(root, c5);
			Position<Choice> b1 = tree.addElementAsChild(a1, c7);
			tree.addExistChild(a2, b1);
			tree.addExistChild(a3, b1);
			tree.addExistChild(a4, b1);
			tree.addExistChild(a5, b1);

			
			Position<Choice> d1 = tree.addElementAsChild(b1, c8);
			Position<Choice> d2 = tree.addElementAsChild(b1, c9);
			Position<Choice> d3 = tree.addElementAsChild(b1, c10);
			
			Position<Choice> e1 = tree.addElementAsChild(d1, c11);
			tree.addExistChild(d2, e1);
			tree.addExistChild(d3, e1);
			//Position<Choice> b2 =tree.addElementAsChild(a2, c5);
			//Position<Choice> b3 =tree.addElementAsChild(a2, c6);
			
			//ArrayList<Position<Choice>> aL = new ArrayList<Position<Choice>>();
			//aL.add(a1);
			//aL.add(a2);
			////aL.add(a3);
			
			
			//Position<Choice> b1 =tree.addListParents(aL, c5);
			//Position<Choice> d1 =tree.addElementAsChild(b1, c6);

			displayNodes(tree, root);
			displayEdge(tree, root);
			System.out.println(tree.preOrderElementTraversal(tree, root));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		////
		
	}
	
	final static int nodeSize = 50;
	final static int edgeSize = 50;
	public static void addNode(int x, int y, Choice elem)
	{
		Button button = new Button(""+elem.getID());
		button.setShape(new Circle(10));
		button.setPrefSize(nodeSize,nodeSize);
		button.setLayoutX(x);
		button.setLayoutY(y);
		pane.getChildren().add(button);
		button.setTextFill(null);
		button.setOnAction(new EventHandler <ActionEvent>()
		{
			
			@Override
			public void handle(ActionEvent event) 
			{
				//total += elem;
				txtTotal.setText(""+total);
				graphPane.setVisible(false);
				
				//this is to search if parent has been visisted
				searchResult = false;
				//this is to search if a fellow child has been visited
				searchChildResult = true;
				try 
				{
					searchParentVisited(tree,  root, Integer.parseInt(button.getText()));
					searchFellowChildVisited(tree,  root, Integer.parseInt(button.getText()));
	
				} catch (Exception e) 
				{
					e.printStackTrace();
				}
				
				

				
				//if parent not visited yet
				if(!searchResult)
				{
					//go to error pane
					ErrorPane root = new ErrorPane("ERROR: Parent of Choice not selected yet.", graphPane);
					Stage secondStage = new Stage();
					
			        secondStage.setScene(new Scene(root));
			        secondStage.setTitle("Error");
			        secondStage.show();
			        return;
					
				}else
				if(!searchChildResult)//now check if a fellow child has already been chosen
				{
								
					//go to error pane
					ErrorPane root = new ErrorPane("ERROR: You cannot choose more than one choice at the same depth", graphPane);
					Stage secondStage = new Stage();
					
			        secondStage.setScene(new Scene(root));
			        secondStage.setTitle("Error");
			        secondStage.show();
			        return;
					
					
				}else
				if(button.getTextFill() == null)//if button viable
				{
					//opens main menu
					InfoPane root = new InfoPane(elem, button, graphPane);
					Stage secondStage = new Stage();
					
			        secondStage.setScene(new Scene(root));
			        secondStage.setTitle("Info");
			        secondStage.show();
					
				}else
				if(button.getTextFill().equals(Color.BLUE))//if buttons already been selected
				{
					//go to error pane
					ErrorPane root = new ErrorPane("ERROR: This option has already been selected.", graphPane);
					Stage secondStage = new Stage();
					
			        secondStage.setScene(new Scene(root));
			        secondStage.setTitle("Error");
			        secondStage.show();
				}else
				{

					
				}
			}			
		});
	}
	
	public static void addEdge(int xP, int yP,int x, int y, Position<Choice> choice)
	{	

		//System.out.println(xP +"-"+yP+"-"+x+"-"+y);
		//create line/edge from start to end
		Line line = new Line(xP+30, yP+30, x+30, y+30);
		Label lblWeight = new Label(""+choice.element().getWeight());
		lblWeight.setLayoutX((xP+30+x+30)/2);
		lblWeight.setLayoutY((yP+30+y+30)/2);
		
		//create directional arrow on line
		//Line arrowUp = new Line(x+15, y+25, x+30, y+30);
		//Line arrowDown = new Line(x+25, y+15, x+30, y+30);
		
		//add line to pane
		//pane.getChildren().add(arrowUp);
		//pane.getChildren().add(arrowDown);
		pane.getChildren().add(line);
		pane.getChildren().add(lblWeight);
	}
	

	static int loop = 0;
	static int iteration = 1;
	static boolean endFound = false;

	private static void displayNodes(Tree<Choice> tree, Position<Choice> choice) throws Exception 
	{
		
		Iterator<Position<Choice>> iterator = tree.children(choice);

		if(tree.parent(choice).get(0) == null)
		{
			choice.element().setX(0);
			choice.element().setY((int)scrollPane.getPrefHeight()/2);

			addNode(0, choice.element().getY(), choice.element());
		}
		
		while(iterator.hasNext())
		{
			//counts at which child you are currently at
			loop++;
			
			if(loop==3)
			{
				loop = 1;
			}
			
			Position<Choice> position = iterator.next();
			
			if(position.element().getDisplayed())
			{
				//System.out.println(position.toString() +"    ddddddd");
			}	
			else
			{
			
			//get depth which is the x axis
			int depth = tree.depth(tree, position)+1;
			
			//calcuate y
			double numChild = tree.getNumChildren(tree.parent(position).get(0));


			
			int parentChoice = 0;
			//determines how a child of one parents should look

			if(tree.parent(position).size() == 1)
			{
				parentChoice = 0;
			}else
			if(tree.parent(position).size() % 2 == 0)//determines how a child of many parents should look - if even
			{
					parentChoice = tree.getNumChildren(tree.parent(position).get(0))/2;
					
				}else//determines how a child of many parents should look - if odd
				{
					
					parentChoice = (int)(tree.getNumChildren(tree.parent(position).get(0))/2+0.5);
					
				}
				
				//this is the # in order ofwhen the child was added to a parent
				int childNum = position.element().getChildNum();
				if(numChild <= 1)
				{
					
					position.element().setY(root.element().getY());
				}
				else
				if(numChild/2 > childNum || childNum==1)//in lower bound of loop
				{
					
					//set above parent
					position.element().setY(tree.parent(position).get(0).element().getY()-200/childNum);
					
				}else
				if(numChild/2 == childNum || numChild/2 == childNum-0.5)//at centre of loop
				{
	
					//set same as parent Y axis
					position.element().setY(tree.parent(position).get(0).element().getY());
	
				}else
				{
					if((numChild+1-childNum) <= 0)
					{
						//set below parent
						position.element().setY((int)(tree.parent(position).get(0).element().getY()+200/(-numChild+1+childNum)));
					}else
					{
						//set below parent
						position.element().setY((int)(tree.parent(position).get(0).element().getY()+200/(numChild+1-childNum)));
					}
					
					
				}
						
	
				if(position.element().getID() == 7)
				{
					System.out.println("numPdasdasasdsad "+ tree.parent(position).size());
				}
				position.element().setX(depth*100);
				if(position.element().getY() > 1000)
				{
					System.out.println("\nID " + position.element().getID()+"   X: "+ position.element().getX()+"   Y: "+position.element().getY());
					System.out.println("loop " + loop+"   numChild: "+numChild+"\n");
				}
				
				
				//add nodes
				addNode(position.element().getX(), position.element().getY(),position.element());
				position.element().setDisplayed();
				//add all edges - can have many parents
				
				/*
				if(tree.getNumChildren(position) == 0)
				{
					loop = 0;
					endFound = true;
					iteration++;
				}*/
			}
			

			
			displayNodes(tree, position);
			
		}
		
	}
	
	private static void displayEdge(Tree<Choice> tree, Position<Choice> choice) throws Exception 
	{
		
		Iterator<Position<Choice>> iterator = tree.children(choice);
		
		while(iterator.hasNext())
		{	
			Position<Choice> position = iterator.next();
			
			Iterator<Position<Choice>> iteratorC = tree.children(position);
			//to add root
			if(tree.parent(choice).get(0) == null)
			{
				addEdge(position.element().getX(),position.element().getY(),choice.element().getX(),choice.element().getY(),position);
			}
			
			while(iteratorC.hasNext())
			{		
				Position<Choice> c = iteratorC.next();
				addEdge(c.element().getX(),c.element().getY(),position.element().getX(),position.element().getY(),c);
			}
			
				displayEdge(tree, position);
			
		}
		
	}

	static boolean searchResult;
	private static void searchParentVisited(Tree<Choice> tree, Position<Choice> choice, int id) throws Exception 
	{
		if(searchResult)
		{
			return;
		}
		Iterator<Position<Choice>> iterator = tree.children(choice);
		//checks if root
		/*if(tree.parent(choice).get(0) == null)
		{
			//checks if root is search id
			if(id == root.element().id)
			{
				searchResult = true;
				return;
			}
		}*/
		
		while(iterator.hasNext())
		{
			if(searchResult)
			{
				return;
			}
			
			if(id == root.element().getID())
			{
				searchResult = true;
				return;
			}

			Position<Choice> position = iterator.next();
			
			//checks if correct node is found
			
			
			
			if(id == position.element().getID())
			{
				

				//checks if parent node has been visited before

				for(Position<Choice> c : tree.parent(position))
				{
					//searchResult = c.element().getVisited();
					System.out.println("Parent ID: " + c.element().getID());
					if(c.element().getVisited())
					{
						searchResult = true;
						return;
					}
				}
				
			}
			
			searchParentVisited(tree, position, id);	
		}	
	}
	
	static boolean searchChildResult;
	private static void searchFellowChildVisited(Tree<Choice> tree, Position<Choice> choice, int id) throws Exception 
	{

		Iterator<Position<Choice>> iterator = tree.children(choice);
		//checks if root
		if(tree.parent(choice).get(0) == null)
		{
			//checks if root is search id
			if(id == root.element().id)
			{
				//System.out.println("root found");
				searchChildResult = true;
				return;
			}
		}
		
		while(iterator.hasNext())
		{
			
			Position<Choice> position = iterator.next();
			//checks if correct node is found
			if(id == position.element().getID())
			{

				//goes over all children of that paren
				Iterator<Position<Choice>> iteratorChild = tree.children(tree.parent(position).get(0));
				
				while(iteratorChild.hasNext())
				{
					
					Position<Choice> positionChild = iteratorChild.next();
					//System.out.println(positionChild.element().getID() + "  "+ positionChild.element().getVisited());
					//if child visited, return false
					if(positionChild.element().getVisited())
					{
						searchChildResult = false;
						return;
					}
				}
					

				
			}
			
			searchFellowChildVisited(tree, position, id);	
		}	
		//System.out.println("failure");
		
	}

}
