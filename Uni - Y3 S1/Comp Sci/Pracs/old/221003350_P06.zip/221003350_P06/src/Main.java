//************ Total marks for Main: 10 marks ************************************
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Random;
import java.util.StringTokenizer;

class Mark{
	String name;
	Integer value;
	
	public Mark(String name, Integer value) {
		this.name = name;
		this.value = value;
	}

	@Override
	public String toString() {
		if (name!=null)
			return name + " " + value;
		else
			return String.valueOf(value);
	}	
}

public class Main {

	public static void main(String[] args) throws Exception {
		Random r = new Random(System.currentTimeMillis());
		
		Tree<Mark> tree = new Tree<Mark>(new Mark("CSC3A", 100));
		Position<Mark> root = tree.root();
		
		Position<Mark> st = tree.addElementAsChild(root, new Mark("ST", 50));
		Position<Mark> st1 = tree.addElementAsChild(st, new Mark(null, (r.nextInt(100))));
		Position<Mark> st2 = tree.addElementAsChild(st, new Mark(null, (r.nextInt(100))));
		
		Position<Mark> miniP = tree.addElementAsChild(root, new Mark("MP", 25));
		Position<Mark> mp = tree.addElementAsChild(miniP, new Mark(null, (r.nextInt(100))));
		
		Position<Mark> ct_pa = tree.addElementAsChild(root, new Mark("CT+PA", 25));
		
		Position<Mark> ct = tree.addElementAsChild(ct_pa, new Mark("CT", 50));		
		for(int i=0;i<3;i++){
			tree.addElementAsChild(ct, new Mark(null, (r.nextInt(100))));
		}
		
		Position<Mark> pa = tree.addElementAsChild(ct_pa, new Mark("PA", 50));		
		for(int i=0;i<8;i++){
			tree.addElementAsChild(pa, new Mark(null, (r.nextInt(100))));
		}
		
		System.out.println(tree.preOrderElementTraversal(tree, root));
		System.out.println("\nSemester Mark:" + calcSM(tree, tree.root()));
	}
	
	/**
	 * Calculate the semester mark using the weights and marks contained in the tree
	 * @param tree
	 * @return the semester mark
	 * 10 marks 
	 * @throws Exception *******************************************************************
	 */
	
	

	static double total = 0;
	private static Double calcSM(Tree<Mark> tree, Position<Mark> root) throws Exception 
	{
		
		Iterator<Position<Mark>> iterator = tree.children(root);

		while(iterator.hasNext())
		{

			
			Position<Mark> position = iterator.next();
			String line = position.toString();
			double mark = 0;
			if(line.contains(" "))
			{
				StringTokenizer st = new StringTokenizer(line);
				st.nextToken();
				mark = Double.parseDouble(st.nextToken());

			}else
			{
				mark = Double.parseDouble(line);
			}
			
			//INDENT IF EXTERNAL NODE
			if(!tree.isInternal(tree, position))
			{
				calcSM(tree, position);
			}
			
			
			/*if(tree.isInternal(tree, position))
			{
				Iterator iteratorChild = tree.children(position);
				
				double total = 0;
				int numChild = 0;
				while(iteratorChild.hasNext())
				{
					total += Double.parseDouble(iteratorChild.next().toString());
					numChild++;
				}
				
				mark = mark*0.01*total/numChild;
				arrayList.add(mark);
			}*/
			
			if(tree.isInternal(tree, position))
			{
				Iterator<Position<Mark>> iteratorChild = tree.children(position);
				
				
				int numChild = 0;
				int totalx = 0;
				boolean flag = false;
				while(iteratorChild.hasNext())
				{

					numChild++;
					Position<Mark> positionC = iteratorChild.next();
					positionC.element().value = (int) (positionC.element().value*mark*0.01);
				
					double markC = 0;
					Mark m = new Mark(positionC.element().name,positionC.element().value);
					
					tree.setElement(positionC, m);
					
					totalx += positionC.element().value;
					
					if(!tree.isInternal(tree, positionC))
					{
						flag = true;
					}
					
				}
				
				if(flag)
				{
					total += totalx/numChild;
				}
				
			}
			

			/*
			//INDENT IF PARENT IS A COMBINATION OF NEXT TWO NODES 
			if(tree.parent(position).toString().contains("+"))
			{
				Position<Mark> positionParent = tree.parent(position);
				String lineP = positionParent.toString();
				double markP = 0;
				if(line.contains(" "))
				{
					StringTokenizer st = new StringTokenizer(lineP);
					st.nextToken();
					markP = Double.parseDouble(st.nextToken());

				}else
				{
					markP = Double.parseDouble(lineP);
				}
				mark = mark*markP*0.01;
			}
			
			*/
			calcSM(tree, position);
		}
		
	

		return total;
		//TODO: Complete
	}

}
