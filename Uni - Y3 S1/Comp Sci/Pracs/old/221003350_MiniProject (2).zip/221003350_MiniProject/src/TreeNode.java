import java.util.ArrayList;
import java.util.Iterator;

public class TreeNode<T> implements Position<T>
{
	T element = null;

	ArrayList<TreeNode<T>> parent = new ArrayList<TreeNode<T>>();
	ArrayList<Position<T>> children;
	int y;
	int x;
	int numChildren = 0;
		
	public TreeNode(TreeNode<T> parent, T element)
	{
		this.parent.add(parent);
		this.element = element;
	}
		
	public TreeNode<T> addChild(T childElem)
	{
		TreeNode<T> newChild = new TreeNode<T>(this, childElem);
		
		if(children == null)
		{
			children = new ArrayList<Position<T>>();
		}
		
		children.add(newChild);	
		numChildren++;
		return newChild;
	}
	
	public int getNumChildren()
	{
		
		return numChildren;
	}
	
	
	public Iterator<Position<T>> getChildren()
	{
		if(children == null)
		{
			children = new ArrayList<Position<T>>();
		}
		return children.iterator();
		
	}
	
	public ArrayList<TreeNode<T>> getParents()
	{
		return parent;
	}
	
	public void addParent(TreeNode<T> parent)
	{
		this.parent.add(parent);
	}
	
	public void setElement(T element)
	{
		this.element = element;
	}

	@Override
	public T element() 
	{
		return element;
	}

	public String toString() {
		return element.toString();		
	}
	

	



}
