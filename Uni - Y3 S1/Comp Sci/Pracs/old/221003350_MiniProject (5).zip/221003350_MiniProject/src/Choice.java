import java.sql.Time;
import java.util.ArrayList;

public class Choice
{

	int id;
	static int idCounter = 0;
	boolean visited;
	boolean displayed;
	int x;
	int y;
	int childnumber = 0;
	
	
	String name;
	String description;
	ArrayList<String> advantages = new ArrayList<String>();
	ArrayList<String> disadvantages = new ArrayList<String>();
	double monthlyRandCost;
	int numMonths;
	int totalRandCost;
	double monthlyTimeCost;
	Time totalTimeCost;
	/**
	 * Name
	 * Description
	 * Advantages
	 * Disadvantages
	 * Monthly Cost
	 * Number Months
	 * Total Cost
	 * 
	 * Monthly Time Cost
	 * Total Time Cost
	 * 
	 */
	
	public Choice(/*String name, String description, */)
	{
		idCounter++;
		id = idCounter;
		
		//this.name = name;
		//this.description = description;
		visited = false;
	
	}
	
	public boolean getVisited()
	{
		return visited;
	}
	
	public void setVisited()
	{
		visited = true;
	}
	
	public boolean getDisplayed()
	{
		return displayed;
	}
	
	public void setDisplayed()
	{
		displayed = true;
	}
	
	
	public int getID()
	{
		return id;
	}
	


	public int getY()
	{
		return y;
	}

	public int getX()
	{
		return x;
	}
	
	
	public void setY(int y)
	{
		this.y = y;
	}
	
	public void setX(int x)
	{
		this.x = x;
	}
	
	public void setChildNum(int childnumber)
	{
		
		this.childnumber = childnumber;
	}
	
	public int getChildNum()
	{
		
		return childnumber;
	}

	
	
	

}
